This directory contains DTD module and entity files from the
REC-xhtml-modularization-20100729 tarball, plus xhtml-ruby-1.mod
retrieved 2010-08-04 from http://www.w3.org/MarkUp/DTD/xhtml-ruby-1.mod;
it is referred to in REC-xhtml-modularization-20100729's xhtml.cat but not
included in the tarball.
